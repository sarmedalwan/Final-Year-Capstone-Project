package Project;

public class Main
{
    public static void main(String[] args) {
        new MainFrame("Game by Sarmed Alwan, 1603088");
    }
}